This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

This project is an application using data from r-spacex open api (https://github.com/r-spacex/SpaceX-API/wiki)

The App.JS file is a quick outline of the public information amongst the launches, and SpaceXs' rockets.

It outlines rocket launches with information about successes and failures amongs their flights

`git clone https://github.com/nachumFreedman/r-spacex
cd r-spacex
yarn
yarn start`